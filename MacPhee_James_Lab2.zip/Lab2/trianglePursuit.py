# James MacPhee - CSCI 2202 - Lab 2
# Part 2|Question 2 - Utilizing turtle1.py to draw pursuit curves of three turtles

from turtle1 import *

#Setup
turt1 = turtle.Turtle(shape="turtle")
turt2 = turtle.Turtle(shape="turtle")
turt3 = turtle.Turtle(shape="turtle")

turt1.pencolor('red')
turt2.pencolor('blue')
turt3.pencolor('green')

turt1.penup()
turt2.penup()
turt3.penup()

turt1.setpos(300,-173.205)
turt2.setpos(-100,-173.205)
turt3.setpos(100,173.205)

turt1.pendown()
turt2.pendown()
turt3.pendown()

turt1.speed(10)
turt2.speed(10)
turt3.speed(10)

#Drawing
while turt3.xcor() != 99.82028120794442:
    turt1.seth(turt1.towards(turt2.pos()))
    turt1.fd(1)
    turt2.seth(turt2.towards(turt3.pos()))
    turt2.fd(1)
    turt3.seth(turt3.towards(turt1.pos()))
    turt3.fd(1)
    
#Finish
turtle.done()
