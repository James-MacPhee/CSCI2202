# James MacPhee - CSCI 2202 - Lab 2
# Question 2 - Utilizing turtle1.py to draw spiral polygons

#I just chose random width by just making the increment different amounts.

#Taking input before import to make the turtle window not appear preemptively
choice = input("Choose shape: (P)entagon, (H)exagon, (O)ctagon, (D)ecagon, d(U)odecagon, (C)ircle: ")
from turtle1 import *

mickey = turtle.Turtle(shape="turtle")
run = 5

#Pentagon
if choice=="P":
    while(run<=200):
        mickey.fd(run)
        mickey.lt(360/5)
        run = run + 5

#Hexagon
if choice=="H":
    while(run<=200):
        mickey.fd(run)
        mickey.lt(360/6)
        run = run + 4

#Octagon
if choice=="O":
    while(run<=150):
        mickey.fd(run)
        mickey.lt(360/8)
        run = run + 3

#Decagon
if choice=="D":
    while(run<=100):
        mickey.fd(run)
        mickey.lt(360/10)
        run = run + 2

#Duodecagon
if choice=="U":
    while(run<=50):
        mickey.fd(run)
        mickey.lt(360/12)
        run = run + 1

#Circle
#I simply made the angle for each turn extremely small to simulate a circle
if choice=="C":
    run = .1
    while(run<=10):
        mickey.fd(run)
        mickey.lt(360/100)
        run = run + 0.01

#Finish
turtle.done()
