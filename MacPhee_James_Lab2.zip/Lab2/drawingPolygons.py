# James MacPhee - CSCI 2202 - Lab 2
# Question 1 - Utilizing turtle1.py to draw polygons 

#Taking input before import to make the turtle window not appear preemptively
choice = input("Choose shape: (P)entagon, (H)exagon, (O)ctagon, (D)ecagon, (U)uodecagon, (C)ircle: ")
from turtle1 import *

mickey = turtle.Turtle(shape="turtle")

#Pentagon
if choice=="P":
    for i in range(5):
        mickey.fd(100)
        mickey.lt(360/5)

#Hexagon
if choice=="H":
    for i in range(6):
        mickey.fd(100)
        mickey.lt(360/6)

#Octagon
if choice=="O":
    for i in range(8):
        mickey.fd(50)
        mickey.lt(360/8)

#Decagon
if choice=="D":
    for i in range(10):
        mickey.fd(50)
        mickey.lt(360/10)

#Duodecagon
if choice=="U":
    for i in range(12):
        mickey.fd(50)
        mickey.lt(360/12)

#Circle
#I simply made the angle for each turn extremely small to simulate a circle
if choice=="C":
    for i in range(360):
        mickey.fd(1)
        mickey.lt(360/360)

#Finish
turtle.done()
