# James MacPhee - CSCI 2202 - Lab 2
# Part 2|Question 1 - Utilizing turtle1.py to draw pursuit curves

from turtle1 import *

#Setup
car = turtle.Turtle(shape="turtle")
dog = turtle.Turtle(shape="turtle")

car.pencolor('red')
dog.pencolor('blue')

x = 400
car.penup()
dog.penup()
car.setpos(-x/2,0)
dog.setpos(0,x/2)
car.pendown()
dog.pendown()

#Drawing
for i in range(400):
    car.fd(1)
    dog.seth(dog.towards(car.pos()))
    dog.fd(1)
    
#Finish
turtle.done()
