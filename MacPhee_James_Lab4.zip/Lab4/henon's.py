#James MacPhee - CSCI 2202 - Lab 3
#Question 4(a) - Using Henon's algortihm to determine square roots of numbers

#Setup
num = int(input("Please enter a number: "))

def mysqrt(x):
    guess = num/(num/2)

    #Calculation
    while abs((guess*guess)-num)>0.001:
        guess = (guess+(num/guess))/2
    return guess
    
print("Square root of "+str(num)+" is "+str(mysqrt(num)))
