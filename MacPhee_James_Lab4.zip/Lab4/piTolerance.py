#James MacPhee - CSCI 2202 - Lab 3
#Question 5 - Calculating pi to approx. user inputted accuracy

#Setup
n = 1
oldPi = 0
pi = 0
change = 0

#Calculation
for i in range(1,100000, 2):
    if change==1:
        pi -= 1/i
        change=0
    else:
        pi += 1/i
        change=1
    n += 1
    if abs(pi-oldPi)<0.0001:
        break
    oldPi = pi

print("pi = "+str(oldPi*4)+"\t# of terms used: "+str(n-1))
