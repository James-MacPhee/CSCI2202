#James MacPhee - CSCI 2202 - Lab 4
#Question 1 - Computes whether an inputted year is a leap year or not

year = int(input("Please enter a year: "))

if year>=1652 and ((year%4==0 and year%100!=0) or year%400==0):
    print(str(year)+" is a leap year.")
else:
    print(str(year)+" is NOT a leap year.")
