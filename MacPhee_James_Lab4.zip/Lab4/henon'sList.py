#James MacPhee - CSCI 2202 - Lab 3
#Question 4(b) - Using Henon's algortihm to determine square roots of numbers

from math import sqrt

#Setup
nums = [10, 20, 30, 40, 50, 60, 70, 80, 90]

print("x\tmysqrt(x)\tmath.sqrt(x)\tdiff")
#Calculation
for num in nums:
    guess = num/(num/2)
    while abs(guess*guess - num)>0.001:
        guess = (guess+(num/guess))/2

    print("%.3f%9.3f%14.3f%16.3f" %(num, guess, sqrt(num), abs(guess-sqrt(num))))
