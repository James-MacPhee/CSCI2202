#James MacPhee - CSCI 2202 - Lab 3
#Question 2 - Reformatting inputted date

fields = [0, 0, 0]
while int(fields[1])<1 or int(fields[1])>12 or int(fields[0])<1 or int(fields[0])>31:
    fields = input("Please input a date in DD-MM-YYYY form: ").split('-')

day = int(fields[0])
month = fields[1]
monthIndex = int(month) #Everything input is a string
year = fields[2]
monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July',\
              'August', 'September', 'October', 'November', 'December']

#Adding suffix
suffix = 'th'
if day%10==1 and day//10!=1:
    suffix = 'st'
elif day%10==2 and day//10!=1:
    suffix = 'nd'
elif day%10==3 and day//10!=1:
    suffix = 'rd'
    
outDate = str(day) + suffix + ' ' + monthNames[monthIndex-1] + ', ' + year
print(outDate)
