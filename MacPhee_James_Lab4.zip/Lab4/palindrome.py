#James MacPhee - CSCI 2202 - Lab 3
#Question 3 - Determining whether inputted word is a palindrome or not

word = input("Please enter a word: ").lower()

if word == word[::-1]:
    print(word+" is a palindrome.")
else:
    print(word+" is NOT a palindrome.")
