#James MacPhee - CSCI 2202 - Lab 3
#Question 5 - Calculating pi to approx. user inputted accuracy

n = int(input("Please enter an integer above 0: "))
pi = 0
change = 0

for i in range(1, n*2, 2):
    if change==1:
        pi -= 1/i
        change=0
    else:
        pi += 1/i
        change=1

print("pi = "+str(pi*4))
