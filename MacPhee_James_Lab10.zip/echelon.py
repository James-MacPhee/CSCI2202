#James MacPhee - CSCI2202 Lab 9/10
#I edited this program slightly, to not print out anything -
#and to return E as well as A in each function

import numpy as np

def add_c_row(A, c, i ,j):
    E = np.eye(len(A))
    E[i,j] = c
    A = E@A
    #A shorter option would be 'A[i] += A[j]*c'
    return A, E

def xchange_rows(A, i, j):
    E = np.eye(len(A))
    E[i,i] = 0
    E[i,j] = 1
    E[j,i] = 1
    E[j,j] = 0
    A = E@A
    #A shorter option is 'A[[i,j]] = A[[j,i]]' 
    return A, E

def scale_row(A, c, i):
    E = np.eye(len(A))
    E[i,i] = c
    A = E@A
    #A shorter option is 'A[i] *= c'
    return A, E