#James MacPhee - CSCI2202 Lab 9/10
#I edited this file to better suit lab10 needs

import numpy as np

#Part (a)
def mMult(X, Y):
    result = np.zeros((len(Y[0]), len(X)))
    for i in range(len(X)):
        for j in range(len(Y[0])):
            for k in range(len(X[0])):
                result[i][j] += X[i][k]*Y[k][j]
    return result

def mMult_noRet(X, Y, Z):
    for i in range(len(X)):
        for j in range(len(Y[0])):
            for k in range(len(X[0])):
                Z[i][j] += X[i][k]*Y[k][j]
    return None

    
