#James MacPhee - CSCI 2202 - Lab 3
#Question 1(a) - Creating asterisk triangle of user inputted size 

R = int(input("Please enter an integer: "))

for i in range(R+1):
    print((i*'*'))
