# James MacPhee - CSCI 2202 - Lab 3
# Question 3 - Utilizing turtle module to draw pursuit curves of N turtles

from turtle1 import *
from math import pi, cos, sin

#Setup
n, d = input("Enter the number of turtles and the preferred distance: ").split()
n = int(n)
d = int(d)
theta = pi*2/n
turtles = []
for i in range(n):
    turtles.append(turtle.Turtle(shape="turtle"))
    turtles[i].ht()
    turtles[i].penup()

#Positioning turtles
for i in range(n):
    angle = theta*i
    turtles[i].setpos(d*cos(angle), d*sin(angle))
    turtles[i].pendown()
    turtles[i].st()

#Drawing
while turtles[1].distance(turtles[2]) > 1:
    print(turtles[1].distance(turtles[2]))
    for i in range(n-1):
        turtles[i].seth(turtles[i].towards(turtles[i+1].pos()))
        turtles[i].fd(1)
    turtles[n-1].seth(turtles[n-1].towards(turtles[0].pos()))
    turtles[n-1].fd(1)
    
#Finish
turtle.done()
