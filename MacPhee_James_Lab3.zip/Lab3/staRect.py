#James MacPhee - CSCI 2202 - Lab 3
#Question 1(a) - Creating asterisk rectangle of user inputted size 

R, C = input("Please enter two integers seperated by a space: ").split()

for i in range(int(R)):
    for i in range(int(C)):
        print('*', end='')
    print()
