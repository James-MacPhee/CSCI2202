#James MacPhee - CSCI 2202 - Lab 3
#Question 2 - Utilizing turtle module to simulate projectile motion

from turtle1 import *
from math import pi, sin, cos

mickey = turtle.Turtle(shape="turtle")
mickey.ht()
angle, velocity = input("Please enter angle and velocity seperated by a space: ").split()

#Setup
x0, y0 = -200, 0
angle = int(angle)*pi/180
velocity = int(velocity)
vx = velocity*cos(angle)
vy = velocity*sin(angle)
travel_time = 16
g = 9.81
mickey.radians()
mickey.penup()
mickey.setpos(x0,y0)
mickey.pendown()
mickey.st()
mickey.seth(angle)
xcors = []
ycors = []
time = []
ran = 0

#Motion
mickey.stamp()
for i in range(1, travel_time):
    #Filling Lists
    xcors.append(mickey.xcor())
    ycors.append(mickey.ycor())
    time.append(i)

    #Calculating and doing the actual motion
    x = x0 + vx*i
    y = y0 + vy*i - g/2*i**2

    mickey.seth(mickey.towards(x,y))   
    mickey.setpos(x, y)
    if y<=0:
        ran = x - x0
        break

    #Stamp
    mickey.stamp()


#Using vf^2 - v0^2 = 2gh equation to get max height
maxHeight = (vy**2)/(2*g)

print("\nMax Height: %.2f" %(maxHeight))
print("Range: %.2f" %(ran))
print("\nTime\t(x, y)")
for i in range(len(xcors)):
    print("%2d\t(%.2f, %.2f)\t" %(time[i], xcors[i], ycors[i]))

turtle.done()
