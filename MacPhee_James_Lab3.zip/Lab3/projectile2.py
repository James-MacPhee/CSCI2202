#James MacPhee - CSCI 2202 - Lab 3
#Question 2 - Utilizing turtle module to simulate projectile motion

from turtle1 import *
from math import pi, sin, cos

#Setup
mickey = turtle.Turtle(shape="turtle")
mickey.ht()
x0, y0 = -200, 0
angles = [20,25,30,35,40,45,50,55,60,65,70,75,80]
ran = []
maxHeights = []

#Loop to basically do 'projectile.py' to each angle
for a in angles:
    angle = a*pi/180
    velocity = 50
    vx = velocity*cos(angle)
    vy = velocity*sin(angle)
    travel_time = 16
    g = 9.81
    mickey.radians()
    mickey.penup()
    mickey.setpos(x0,y0)
    mickey.pendown()
    mickey.st()
    mickey.seth(angle)
    xcors = []
    ycors = []
    time = []

    #Motion
    mickey.stamp()
    for i in range(1, travel_time):
        #Calculating and doing the actual motion
        x = x0 + vx*i
        y = y0 + vy*i - g/2*i**2

        mickey.seth(mickey.towards(x,y))   
        mickey.setpos(x, y)
        if y<=0:
            ran.append(x - x0)
            break

        #Stamp
        mickey.stamp()


    #Using vf^2 - v0^2 = 2gh equation to get max height
    maxH = (vy**2)/(2*g)
    maxHeights.append(maxH)


print("\nMax Height\tRange")
for i in range(len(ran)):
    print("%.2f\t%14.2f" %(maxHeights[i], ran[i]))

turtle.done()
