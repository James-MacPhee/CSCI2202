#James MacPhee - CSCI2202 Lab 9
#Question 1 - Transforms a matrix to reduced echelon form

import numpy as np

def add_c_row(A, c, i ,j):
    E = np.eye(len(A))
    E[i,j] = c
    A = E@A
    #A shorter option would be 'A[i] += A[j]*c'
    return A

def xchange_rows(A, i, j):
    E = np.eye(len(A))
    E[i,i] = 0
    E[i,j] = 1
    E[j,i] = 1
    E[j,j] = 0
    A = E@A
    #A shorter option is 'A[[i,j]] = A[[j,i]]' 
    return A

def scale_row(A, c, i):
    E = np.eye(len(A))
    E[i,i] = c
    A = E@A
    #A shorter option is 'A[i] *= c'
    return A

def echelon_reduce(M, b):
    result = np.hstack((M,b))
    #Making pivot in first column
    result = scale_row(result, 1/6, 0)
    #Eliminating lower first column entries
    result = add_c_row(result, -8, 1, 0)
    result = add_c_row(result, -2, 2, 0)
    #Making pivot in second column
    result = scale_row(result, -1/13, 1)
    #Eliminating lower second column entries
    result = add_c_row(result, -2, 2, 1)
    #Making pivot in third column
    result = scale_row(result, 13/121, 2)
    return result

def diag_elim(M):
    result = echelon_reduce(M,b)
    result = np.delete(result, 3, 1)
    result = xchange_rows(result,0,1)
    result = xchange_rows(result,2,1)
    result = add_c_row(result, -1/6, 2, 1)
    return result
M = np.array([[6, 15, 1], [8, 7, 12], [2, 7, 8]])
b = np.array([[2], [14], [10]])

print(f'Original:\n{np.hstack((M,b))}')
print(f'\nReduced Echelon Form:\n{echelon_reduce(M,b)}')
print(f'\nDiagonal elements eliminated (just M):\n{diag_elim(M)}')
