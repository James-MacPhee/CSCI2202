#James MacPhee - CSCI2202 Lab 9
#Question 3 - Creates an adjacency matrix given pairs of vertices

import numpy as np

#Part 1
pairs = [(1,2), (2,1), (2,5), (3,2), (3,5), (4,3), (4,5), (5,2), (5,4)]
A = np.zeros((5,5))
B  = np.zeros((5,5))
for pair in pairs:
    A[tuple(np.subtract(pair,(1,1)))] += 1

print(f'Adjacency matrix for given pairs: \n{A}')

#Part 2
k = input('\nPlease enter an integer k: ')
#Computing A to the k'th power
temp = A
for i in range(int(k)-1):
    temp = A@temp

print(f'Number of walks of length k for each pair of vertices: \n{temp}')
