#James MacPhee - CSCI2202 Lab 9
#Question 2 - Performs matrix multiplication in pure Python

import numpy as np

#Part (a)
def mMult(X, Y):
    result = np.zeros((len(Y[0]), len(X)))
    for i in range(len(X)):
        for j in range(len(Y[0])):
            for k in range(len(X[0])):
                result[i][j] += X[i][k]*Y[k][j]
    return result

def mMult_noRet(X, Y, Z):
    for i in range(len(X)):
        for j in range(len(Y[0])):
            for k in range(len(X[0])):
                Z[i][j] += X[i][k]*Y[k][j]
    return None

#Creating random test matrices
A = np.random.randint(9, size=(5, 5), dtype='int')
B = np.random.randint(9, size=(5, 5), dtype='int')

print(mMult(A, B))
print(A@B)

print('\n\nPart B:')

#Part (b)
P = np.array([[0.96,0.01],[0.04,0.99]])
x0 = np.array([82,163]).T
def xn(year):
    n = year-2007
    temp = P
    for i in range(n):
        temp = mMult(temp, P)
    return temp

for i in range(5):
    print(2007+i)
    print(f'{xn(2007+i)}\n')
    
