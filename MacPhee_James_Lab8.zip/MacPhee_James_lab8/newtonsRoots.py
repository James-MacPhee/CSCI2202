#James MacPhee - CSCI2202 Lab 8
#Question 2 - Using newtons method to find roots of given functions

import numpy as np
import matplotlib.pyplot as plt

def newton(f, df, x0, eps):
    i = 0
    while abs(f(x0))>eps:
        if df(x0)==0:
            print('No solution found.')
            return None
        x0 = x0 - f(x0)/df(x0)
        i += 1
    return x0, i

def newton2(f, df, x0, eps):
    i = 0
    while abs(f(x0))>eps and i<40:
        if df(x0)==0:
            print('No solution found.')
            return None
        x0 = x0 - f(x0)/df(x0)
        plot_line(f, x0, df(x0), 1)
        input('Hit Enter to Continue')
        i += 1
    return x0, i

def funcd(x):
    return x**2-x-1

def derivD(x):
    return 2*x-1

def funce(x):
    return np.log(2+x) - np.sqrt(x)

def derivE(x):
    return -1/(2-x) - 1/(2*np.sqrt(x))

def newFunc(x):
    return np.tanh(x)

def newDeriv(x):
    return 1 - np.tanh(x)**2

def plot_line(f, xn, fxn, slope):
    xf = np.linspace(-2,2,100)
    yf = f(xf)
    xt = np.linspace(xn-2, xn+2,10)
    yt = slope*xt + (fxn - slope*xn) # Straight line:  ax + b
    plt.figure()
    plt.plot(xt, yt, 'r-', xf, yf, 'b-')
    plt.grid('on')
    plt.xlabel('x')
    plt.ylabel('f(x)')
    plt.show()

def plotting(f, start, stop):
    x = np.arange(start, stop)

    plt.plot(x,f(x))
    plt.show()

def printing(ans):
    if ans=='d':
        posx, numIter = newton(funcd, derivD, 1.5, 10e-8)
        negx, numIter = newton(funcd, derivD, -0.5, 10e-8)
        print(f'Roots of f(x)=x^2-x-1 are: x = {negx} & x = {posx}')

    else:
        plotting(funce, 0, 10)
        root, numIter = newton(funce, derivE, 1, 10e-8)
        print(f'x = {root}, f(x) = {funce(root)}, and iterations = {numIter}')

printing('d')
print()
printing('e')
newton2(newFunc, newDeriv, 1.08, 10e-8)
