#James MacPhee - CSCI2202 Lab 8
#Question 1 - Using bisection method to find roots of given functions

import numpy as np
import matplotlib.pyplot as plt

def bisection(x0, x1, eps, f):
    m = (np.log(x1-x0) - np.log(2*eps))/np.log(2)
    x2 = (x0+x1)/2.0
    i = 1
    while abs(f(x2))>eps and i<=m:
        if f(x0)*f(x2)<0:
            x1 = x2
        else:
            x0 = x2
        x2 = (x0+x1)/2.0
        i += 1

    return x2, i

def funcd(x):
    return x**2-x-1

def funce(x):
    return np.log(2+x) - np.sqrt(x)

def funcf1(x):
    return x**3 - 3*x - 1

def funcf2(x):
    return x**3 - 2*np.sin(x)

def funcf3(x):
    return np.tan(x) - 2*x

def plotting(f, start, stop):
    x = np.linspace(start, stop)
    y = f(x)

    plt.plot(x,y)
    plt.show()

def printing(ans):
    if ans=='d':
        posx, numIter = bisection(1, 2, 10e-8, funcd)
        negx, numIter = bisection(-1, 0, 10e-8, funcd)
        print(f'Roots of f(x)=x^2-x-1 are: x = {negx} & x = {posx}')

    elif ans=='e':
        plotting(funce, 0, 10)
        root, numIter = bisection(0, 10, 10e-8, funce)
        print(f'x = {root}, f(x) = {funce(root)}, and iterations = {numIter}')
    else:
        plotting(funcf1, -0.5, 1)
        root1, numIter1 = bisection(-0.5, 1, 10e-8, funcf1)
        plotting(funcf2, 0.5, 2)
        root2, numIter2 = bisection(0.5, 2, 10e-8, funcf2)
        plotting(funcf3, 0.5, 2)
        root3, numIter3 = bisection(0.5, 2, 10e-8, funcf3)
        print(f'x = {root1}, f(x) = {funcf1(root1)}, and iterations = {numIter1}')
        print(f'x = {root2}, f(x) = {funcf2(root2)}, and iterations = {numIter2}')
        print(f'x = {root3}, f(x) = {funcf3(root3)}, and iterations = {numIter3}')
        
    return 

choice = input('Which question of lab #8 would you like the answer to (d, e, f)? ')
printing(choice)
