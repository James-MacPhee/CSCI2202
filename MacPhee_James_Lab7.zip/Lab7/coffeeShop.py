#James MacPhee - CSCI2202 Lab7
#Question 2 - Simulating friends waiting for eachother at a coffee shop

import random as rn

def coffeeSim(num, m, c):
    meets = 0
    #I chose to run the sim. 1000 times
    for i in range(num):
        #Making random arrival times
        #I'm assuming 9:30 and 10:00 are inclusive
        mollie = rn.randint(0, 30)
        chloe = rn.randint(0, 30)
        mFirst = chloe-mollie
        cFirst = mollie-chloe
        
        if (mFirst<m and mFirst>0) or (cFirst<c and cFirst>0):
            meets += 1
    return meets/num
    
ans = int(input('Enter # of trials to run: '))
print(f'\nProbability of meeting: {coffeeSim(ans, 5, 7)}')
print(f'Probability w/ chloe less patient: {coffeeSim(ans, 5, 5)}')
print(f'Probability w/ mollie more patient: {coffeeSim(ans, 7, 7)}')
