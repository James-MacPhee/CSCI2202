#James MacPhee - CSCSI2202 Lab 7
#Question 1a - Finding roots of a quadratic equation

from math import sqrt

user_input = input('Enter a, b, and c: ').split()
a = int(user_input[0])
b = int(user_input[1])
c = int(user_input[2])

#Getting the discriminant
disc = b**2-4*a*c

if disc < 0:
    print('Has complex roots')
else:
    print(f'Roots: x = {(-b+sqrt(disc))/(2*a)} & x = {(-b-sqrt(disc))/(2*a)}')
