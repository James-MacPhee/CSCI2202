#James MacPhee - CSCSI2202 Lab 7
#Question 1d - Determining if quadratic equation has complex roots

user_input = input('Enter a, b, and c: ').split()
a = int(user_input[0])
b = int(user_input[1])
c = int(user_input[2])

def hasComplexRoots(a, b, c):
    disc = b**2-4*a*c

    if disc < 0:
        return True
    else:
        return False

print('Has complex roots? {hasComplexRoots(a, b, c)}')
