#James MacPhee - CSCSI2202 Lab 7
#Question 1c - Computes whether inputted year is a leap year or not

user_input = int(input("Please enter a year: "))

def is_leap(year):
    if year>=1652 and ((year%4==0 and year%100!=0) or year%400==0):
        return True
    else:
        return False

print(f'Is {user_input} a leap year? {is_leap(user_input)}')
