#James MacPhee - CSCSI2202 Lab 7
#Question 1e - Using Monte Carlo estimate complex root probability

import random as rn

def hasComplexRoots(a, b, c):
    disc = b**2-4*a*c

    if disc < 0:
        return True
    else:
        return False

countUni = 0
countNorm = 0
#I know it said to repeated experiment but I just put both Uniform and Normal -
#in the same function to cut down on code
for i in range(1000):

    a1 = rn.random()
    b1 = rn.random()
    c1 = rn.random()
    a2 = rn.normalvariate(0, 1)
    b2 = rn.normalvariate(0, 1)
    c2 = rn.normalvariate(0, 1)

    if hasComplexRoots(a1, b1, c1):
        countUni += 1
    if hasComplexRoots(a2, b2, c2):
        countNorm += 1

print(f'Probability of having complex roots for uniform dist. = {countUni/1000}')
print(f'Probability of having complex roots for normal dist. = {countNorm/1000}')
