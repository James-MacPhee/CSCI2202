#James MacPhee - CSCI2202 Assignment 2
#Question 1 - Implements the False Position method for root-finding

import numpy as np

#False position method implementation
def falsePos(x0, x1, tol, m, f):
    x2 = (x1-x0)*f(x1)/(f(x1)-f(x0))
    i = 1
    while(abs(f(x2)) >= tol and i <= m):
        x2 = x1 - (x1-x0)*f(x1)/(f(x1)-f(x0))
        if(f(x0)*f(x2)<0):
            x1 = x2
        else:
            x0 = x2
        i += 1
        
    return x2, i

#Newton-Raphson method implementation
def newton(f, df, x0, eps):
    i = 0
    while abs(f(x0))>eps:
        if df(x0)==0:
            print('No solution found.')
            return None
        x0 = x0 - f(x0)/df(x0)
        i += 1
    return x0, i

#Bisection method implementation
def bisection(x0, x1, eps, f):
    m = (np.log(x1-x0) - np.log(2*eps))/np.log(2)
    x2 = (x0+x1)/2.0
    i = 1
    while abs(f(x2))>eps and i<=m:
        if f(x0)*f(x2)<0:
            x1 = x2
        else:
            x0 = x2
        x2 = (x0+x1)/2.0
        i += 1

    return x2, i


#Given mathematical function
def func(x):
    return np.log(2+x) - np.sqrt(x)

def deriv(x):
    return 1/(x+2) - 1/(2*np.sqrt(x))

fRoot, fCount = falsePos(0, 10, 10E-8, 100, func)
nRoot, nCount = newton(func, deriv, 1, 10E-8)
bRoot, bCount = bisection(0, 10, 10E-8, func)

print('False Position Method:')
print(f'x = {fRoot}\t|f(x)| = {abs(func(fRoot))}\tIterations: {fCount}')
print('\nNewton-Raphson Method:')
print(f'x = {nRoot}\t|f(x)| = {abs(func(nRoot))}\tIterations: {nCount}')
print('\nBisection Method:')
print(f'x = {bRoot}\t|f(x)| = {abs(func(bRoot))}\tIterations: {bCount}')

print('It appears that false position is much slower than the other methods.')
