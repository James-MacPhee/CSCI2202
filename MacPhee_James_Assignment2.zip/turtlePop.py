#James MacPhee - CSCI2202 Assignment 2
#Question 4 - Models the population dynamics of turtles

import numpy as np

np.set_printoptions(suppress=True)

#Making stages
stage1 = (1, 0.67, 0)
stage2 = (20, 0.74, 0)
stage3 = (1, 0.81, 127)
stage4 = (31, 0.81, 79)
stages = [stage1, stage2, stage3, stage4]

#Creating function to easily access proper values
def p(n):
    s = stages[n-1][1]
    d = stages[n-1][0]
    return ((1 - s**(d-1))/(1 - s**d))*s

def q(n):
    s = stages[n-1][1]
    d = stages[n-1][0]
    return ((1 - s)*(s**d))/(1 - s**d)

def e(n):
    return stages[n-1][2]

#Making Leslie matrix
def createLeslie():
    tmp = np.zeros((4, 4))
    tmp[0][0] = p(1)
    tmp[0][1] = e(2)
    tmp[0][2] = e(3)
    tmp[0][3] = e(4)
    tmp[1][0] = q(1)
    tmp[1][1] = p(2)
    tmp[2][1] = q(2)
    tmp[2][2] = p(3)
    tmp[3][2] = q(3)
    tmp[3][3] = p(4)
    return tmp

x0 = np.array((200000, 300000, 500, 1500))
times = [1, 10, 20, 50, 100]

#Function to find population given end of time period
def pop(t, L):
    return np.dot(x0, np.linalg.matrix_power(L,t))

#Part (a)
La = createLeslie()

#Printing results
for i in times:
    print(f'{i}\n{np.around(pop(i, La), 0)}')

print()
#Part (b)
temp = (1, 0.77, 0)
stages[0] = temp
Lb = createLeslie()

#Printing results
for i in times:
    print(f'{i}\n{np.around(pop(i, Lb), 0)}')

print()
#Part (c)
temp = (1, 0.67, 0)
stages[0] = (1, 0.67, 0)
temp = (21, 0.88, 0)
stages[1] = temp
Lc = createLeslie()

#Printing results
for i in times:
    print(f'{i}\n{np.around(pop(i, Lc), 0)}')
