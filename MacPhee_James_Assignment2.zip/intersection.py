#James MacPhee - CSCI2202 Assignment 2
#Question 3 - Finding points of intersections

#Imports
import numpy as np

#Creating range of 'x' values and functions
x = np.arange(-2.0, 2.0, 0.0001)
f1 = x**3 - 2*x + 1
f2 = x**2

#This line basically finds all indices of the above 'x' where - 
#the sign of f1-f2 changes then converts that to a proper value
Xvalues = np.argwhere(np.diff(np.sign(f1 - f2)))*0.0001 - 2
Yvalues = Xvalues**2

#Printing results
for i in range(len(Xvalues)):
    print(f'({Xvalues[i][0]:.4f}, {Yvalues[i][0]:.4f})')
