#James MacPhee - CSCI2202 Assignment 2
#Question 2 - Solves the given equation with the bisection method

#Imports
import numpy as np

#Bisection method implementation
def bisection(x0, x1, eps, f):
    m = (np.log(x1-x0) - np.log(2*eps))/np.log(2)
    x2 = (x0+x1)/2.0
    i = 1
    while abs(f(x2))>eps and i<=m:
        if f(x0)*f(x2)<0:
            x1 = x2
        else:
            x0 = x2
        x2 = (x0+x1)/2.0
        i += 1

    return x2, i


#Given mathematical function
def func(x):
    return x*np.cosh(50/x) - x - 10

#Calculation
bRoot, bCount = bisection(25, 200, 10E-8, func)

print(f'x = {bRoot:.4f}\tIterations: {bCount}')
