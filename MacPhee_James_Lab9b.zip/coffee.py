#James MacPhee - CSCI2202 Lab 9b
#Question 1, 2, & 3 - Deomstrates simple plotting and regeression techniques

import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as sp

#Question 1
def readDatFile(inFile):
    #Obviously there are easier ways,
    #I just assumed you wanted it in pure python
    f = open(inFile, 'r')
    x = []
    y = []
    for line in f:
        line = line.strip()
        columns = line.split()
        x.append(float(columns[0]))
        y.append(float(columns[1]))

    return np.array(x), np.array(y)

#Question 2
x, y = readDatFile('coffeeTemp.txt')
plt.scatter(x, y)
plt.xlabel('Time')
plt.ylabel('Temperature')
plt.show()

#Question 3
#Creating new variables
deltaT = np.diff(y)
temp = []
for i in range(len(y)):
    temp.append(y[i]-22)
temp = np.array(temp)[:-1]

#Regression line
slope, intercept, r_value, p_value, std_err = sp.linregress(temp, deltaT)

#Plotting
plt.plot(temp, deltaT, '.')
plt.plot(temp, intercept + slope*temp, '-')
plt.xlabel('DeltaT')
plt.ylabel('Tn - T0')
plt.show()
