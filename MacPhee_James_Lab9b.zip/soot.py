#James MacPhee - CSCI2202 Lab9b
#Question 4 -

import numpy as np
import scipy.optimize as sp

def readDatFile(inFile):
    #Obviously there are easier ways,
    #I just assumed you wanted it in pure python
    f = open(inFile, 'r')
    x = []
    y = []
    for line in f:
        line = line.strip()
        columns = line.split()
        x.append(float(columns[0]))
        y.append(float(columns[1]))

    return np.array(x), np.array(y)

radius, time = readDatFile('sootAggregation.txt')
def power_law(x, r0, n):
    return r0*x**n

#Fitting regression curve and finding parameters r0 and n
params, pcov = sp.curve_fit(power_law, time, radius)
print(f'r0 = {params[0]}\tn = {params[1]}')
