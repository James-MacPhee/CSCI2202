#James MacPhee - CSCI2202 - Lab 5
#Question 3 - Demostrating truncation error in a taylor series

import math

def taylor(x, n):
    e = 0
    for i in range(n):
        e += x**i/math.factorial(i)
    
    return e

approx = taylor(1, 5)
#I used exp(1) because using exp(-1) doesn't seem to make much sense
exact = math.exp(1)
error = (approx - exact)/exact
print(f'approx= {approx}, exact= {exact}, rel. error = {error}')
