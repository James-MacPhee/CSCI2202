#James MacPhee - CSCI2202 - Lab 5
#Question 1 - Computes an estimate of machine epsilon

em = 1
while em+1 > 1:
    em /= 2
print("Machine epsilon is: "+str(em))
