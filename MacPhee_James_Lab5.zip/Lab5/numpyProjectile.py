#James MacPhee - CSCI2202 - Lab 5
#Question 4 - Practicing with Matplotlib

import numpy as np
import matplotlib.pyplot as plt
from math import sin, cos, pi

choice = input("Please enter angle and velocity seperated by a space: ").split()

#Setup
x0, y0 = -200, 0
theta = int(choice[0])*pi/180
v0 = int(choice[1])
vx = v0*cos(theta)
vy = v0*sin(theta)
g = 9.81
t = np.linspace(start=0, stop=round(2*v0/g), num=round(2*v0/g), endpoint=False)
x = x0 + vx*t
y = y0 + vy*t - .5*g*t**2

yMax = 0
yMaxTime = 0
xMax = 0
xMaxTime = 0

for i in range(len(t)):
    if y[i]>yMax:
        yMax = y[i]
        yMaxTime = t[i]
    if y[i]<0:
        xMax = x[i]
        xMaxTime = t[i]
        break

#Printing results
print(f'Reaches max height of {yMax:.3f}m at {yMaxTime}s')
print(f'Reaches max range of {(xMax+200):.3f}m at {xMaxTime}s')

for i in range(int(xMaxTime)+1):
    print(f'|{t[i]:6.3f}s | ({x[i]:6.3f}m,{y[i]:6.3f}m)')
    
#Plotting
plt.plot(x, y,'b-')
plt.xlabel("x")
plt.ylabel("y")
plt.show()
