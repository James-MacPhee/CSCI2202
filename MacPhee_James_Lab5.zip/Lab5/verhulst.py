#James MacPhee - CSCI2202 - Lab 5
#Question 2 - Using the Verhulst equation to demonstrate round-off error

from math import isclose

#Setup
r = 3
num1 = 0.01
num2 = 0.01
count = 0

#I chose to use iteration over recursion because I don't have -
#much familiarty with tail recursion in python
for i in range(50):
    print(f'{num1:.12f} {num2:.12f}')
    num1 = num1 + r*num1*(1-num1)
    num2 = (1+r)*num2 - r*num2**2
    if abs(num1-num2)<=0.000000000001:
        count = i
print(f'\nThe numbers start to deviate at iteration {count}')
