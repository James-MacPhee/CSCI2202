#James MacPhee - CSCI2202 Assignment 1
#Question 5 - Finding mutations in DNA sequences

#I am assuming that the input will have an inverted pair

dna = input('Enter a DNA sequence: ')
pattern = input('Enter the pattern: ')
mutation = ''
index = dna.find(pattern)
for i in range(4, 8):
    mutation += dna[index+i]

dna = dna.partition(mutation)
print(f'Muatated DNA sequence: {dna[0]}{dna[1][::-1]}{dna[2]}')
