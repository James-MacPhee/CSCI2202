# James MacPhee - CSCI 2202 - Assignment 1
# Question 1 - Utilizing turtle1.py to draw rotated polygons 

import turtle

#Setup
sides = int(input('Enter num sides: '))
shapes = int(input('Enter num polygons: '))
turtleWindow = turtle.Screen()
turtleWindow.title("Rotated Polygons")
turt = turtle.Turtle(shape="turtle")
turt.pencolor('blue')
colour = 0

#Drawing
for i in range(shapes):
    for j in range(sides):
        turt.fd(500/sides)
        turt.lt(360/sides)
    turt.lt(360/shapes)
    if colour==0:
        turt.pencolor('red')
        colour = 1
    else:
        colour = 0
        turt.pencolor('blue')


#Finish
turtle.done()
