#James MacPhee - CSCI2202 Assignment 1
#Question 2 - A simple program showcasing the definition of a derivative

from math import sin, cos

h = 1
exact = cos(.5)
print(f'\t\tExact value: {exact}')
for i in range(10):
    h = h/4
    y = (sin(.5+h)-sin(.5))/h
    print(f'Estimate: {y}\tRelative Error: {(y-exact)/exact}')

