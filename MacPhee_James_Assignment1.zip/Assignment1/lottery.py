#James MacPhee - CSCI2202 Assignment 1
#Question 3 - Simulate a simple number guessing game

import random as rn

choice = input('Welcome! Would you like to play a game [y/n]? ')
while choice=='y': #Loop to keep playing game
    guess = input('Please guess a two digit number: ')
    num1 = int(guess[0])
    num2 = int(guess[1])
    #Couldn't find a function that gave distinct digits so I did it from scratch
    seq = list(range(1,10)) 
    ans1 = rn.choice(seq)  
    del seq[ans1-1]
    seq.append(0)
    ans2 = rn.choice(seq)

    if num1==ans1 and num2==ans2:
        print(f'Guess: {guess}\tSecret #: {str(ans1)}{str(ans2)}')
        print('Congrats! You\'re amazing, collect your free Ferrari at the door!')
    elif num1==ans2 and num2==ans1:
        print(f'Guess: {guess}\tSecret #: {str(ans1)}{str(ans2)}')
        print('Please collect your disorder prize at the door.')
    elif num1==ans1 or num2==ans2:
        print(f'Guess: {guess}\tSecret #: {str(ans1)}{str(ans2)}')
        print('Please collect your consolation prize at the door.')
    else:
        print(f'Guess: {guess}\tSecret #: {str(ans1)}{str(ans2)}')
        print('You suck, try again.')

    choice = input('\nWould you like to play again [y/n]? ')

print('Have a great day and thanks for playing :)')
