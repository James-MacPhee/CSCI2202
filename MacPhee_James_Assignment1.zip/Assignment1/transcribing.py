#James MacPhee - CSCI2202 Assignment 1
#Question 4 - Transcribing simple DNA->RNA sequences

dna = input('Enter a DNA sequence: ')
rna = ''

for i in dna:
    if i=='A':
        rna += 'U'
    elif i=='C':
        rna += 'G'
    elif i=='G':
        rna += 'C'
    else:
        rna += 'A'

print('Transcribed RNA sequence: '+rna)
