#James MacPhee - CSCI2202 Assignment 1
#Question 6 - Simulating the Monte Hall problem 'n' times

import random as rn

n = int(input('Please enter # of games: '))

#Function that simulates one play-through of the game
def play_game(switch):
    #Choosing doors
    doors = [1, 2, 3]
    prize = rn.choice(doors)
    choice = rn.choice(doors)
    for i in doors:
        if i not in [prize, choice]:
            reveal = i
    if switch:
        if prize!=choice:
            return True
    else:
        if prize==choice:
            return True
    return False

#Strategy of NOT switching doors
def game(n):
    no_wins = 0
    for i in range(n):
        if play_game(True):
            no_wins += 1
    return no_wins/n

#Strategy of switching doors
def s_game(n):
    yes_wins = 0
    for i in range(n):
        if play_game(False):
            yes_wins += 1
    return yes_wins/n

#Printing results
print(f'W/L Ratio w/ switching: {s_game(n)}')
print(f'W/L Ratio w/o switching: {game(n)}')

#Printing results for n=1000, 10000
print(f'\nW/L Ratio (n=1000): no switching: {game(1000)}\tswitching: {s_game(1000)}')
print(f'W/L Ratio (n=10000): no switching: {game(10000)}\tswitching: {s_game(10000)}')
