#James MacPhee - CSCI2202 Project
#Contains functions to setup PageRank

import numpy as np

def adjMatrixFromFile(fileName):
    #Opening file
    file = open(fileName)
    data = file.read().split('\n')

    #Setting up matrix
    numNodes = int(data[0])
    adjMatrix = np.zeros((numNodes, numNodes))

    #Populating matrix
    i = 1
    while i < len(data):
        tempData = data[i].split()
        j = 0

        while j < len(tempData):
            num1 = int(tempData[j])
            num2 = int(tempData[j+1])
            adjMatrix[num1, num2] += 1
            j += 2
        i += 1
        
    file.close()
    return adjMatrix

def adjMatrixSingleLinksOnly(fileName):
    #Opening file
    file = open(fileName)
    data = file.read().split('\n')

    #Setting up matrix
    numNodes = int(data[0])
    adjMatrix = np.zeros((numNodes, numNodes))

    #Populating matrix
    i = 1
    while i < len(data):
        tempData = data[i].split()
        j = 0

        while j < len(tempData):
            num1 = int(tempData[j])
            num2 = int(tempData[j+1])
            adjMatrix[num1, num2] = 1
            j += 2
        i += 1
        
    file.close()
    return adjMatrix

#Function to determine out degrees
def outDegrees(adjM):
    outDegree = np.sum(adjM, axis=1)
    return outDegree.reshape((len(adjM), 1))

#Function to determine transition probabilities
def transitionProbabilities(adjM, outDeg):
    n = len(adjM)
    tranMatrix = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            tranMatrix[i][j] = 0.9*adjM[i][j]/outDeg[i][0] + 0.1/n
    return tranMatrix
