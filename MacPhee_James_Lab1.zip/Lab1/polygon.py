# James MacPhee - CSCI 2202 - Lab 1
# Question Part2 #6 - Utilizing turtle1.py to draw user inputted sided polygons 

from turtle1 import *

numSides = int(input("Enter the number of sides: "))

#Turtle movement
for i in range(numSides):
    
    #If/else statement to try and make sure image fits on screen
    if numSides > 10:
        mickey.fd(10)
    else:
        mickey.fd(100)
    mickey.lt(360/numSides)

#Finish
turtle.done()
