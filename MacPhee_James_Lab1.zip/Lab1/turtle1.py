# James MacPhee - CSCI 2202 - Lab 1
# Question Part2 #1-5- Main turtle graphics module

import turtle

#setup
turtleWindow = turtle.Screen()
turtleWindow.title("Turtle Drawing Demo")
mickey = turtle.Turtle(shape="turtle")
