# James MacPhee - CSCI 2202 - Lab 1
# Question #4 - A simple trajectory calculation

v_0 = 5
g = 9.81
t = 0.6
y = v_0*t - 0.5*g*t**2
print("At t = " +str(t) + " the position of the ball is: " + str(y))
