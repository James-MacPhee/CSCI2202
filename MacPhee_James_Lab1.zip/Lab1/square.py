# James MacPhee - CSCI 2202 - Lab 1
# Question Part2 #6 - Utilizing turtle1.py to draw squares 

from turtle1 import *

#Using repeated code
mickey.pencolor("yellow")
mickey.fd(100)
mickey.lt(90)
mickey.pencolor("red")
mickey.fd(100)
mickey.lt(90)
mickey.pencolor("green")
mickey.fd(100)
mickey.lt(90)
mickey.pencolor("blue")
mickey.fd(100)

#Making a gap
mickey.penup()
mickey.fd(10)
mickey.pendown()

#Using a loop to make an identical square
colors = ["blue", "yellow", "red", "green"]
for i in colors:
    mickey.pencolor(i)
    mickey.fd(100)
    mickey.lt(90)

#Finish
turtle.done()
