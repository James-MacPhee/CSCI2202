# James MacPhee - CSCI 2202 - Lab 1
# Question Part2 #6 - Utilizing turtle1.py to draw a hexagon 

from turtle1 import *

#Turtle movement
for i in range(6):
    mickey.fd(100)
    mickey.lt(60)

turtle.done()
