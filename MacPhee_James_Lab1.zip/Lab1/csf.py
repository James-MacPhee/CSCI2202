# James MacPhee - CSCI 2202 - Lab 1
# Question #5 - Converts celcius to fahrenheit

c = float(input("Enter a temperature in degrees C: "))
f = 9/5*c + 32
print(str(c)+" degrees Celcius is "+str(f)+" degrees fahrenheit.")
