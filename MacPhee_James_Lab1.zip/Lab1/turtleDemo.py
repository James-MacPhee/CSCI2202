# James MacPhee - CSCI 2202 - Lab 1
# Question Part2 #5 - Testing turtle1.py 

from turtle1 import *

mickey.pencolor("blue")
#movement
mickey.fd(100)
mickey.lt(90)
mickey.fd(100)
mickey.bk(100)
mickey.lt(90)
mickey.fd(100)
mickey.bk(50)

#finish
turtle.done()
