#James MacPhee - CSCI2202 Test2
#Question 1 - Finding likelihoods of certain die rolls

import numpy as np

#Function that simulates six rolls
def sixRolls():
    num = 0
    for i in range(6):
        roll = np.random.randint(1, 7)
        if roll == 6:
            num += 1

    return num/6

#Function that simulates twelve rolls
def twelveRolls():
    num = 0
    for i in range(12):
        roll = np.random.randint(1, 7)
        if roll == 6:
            num += 1
    return num/12

sixes = 0
twelves = 0
#Loop to run each simulation 100,000 times
for n in range(100000):
    sixes += sixRolls()
    twelves += twelveRolls()

#Calculating and printing average over the 100,000 simulations
sixes = sixes/100000
twelves = twelves/100000
print("Odds of one '6' in six rolls: " + str(sixes))
print("Odds of two '6's in twelve rolls: " + str(twelves))
print("\nThey are both right near 1/6 chance")
print("But the odds of one 6 in 6 rolls being slighter better")
