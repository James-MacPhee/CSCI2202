#James MacPhee - CSCI2202 Test2
#Question 2 - Finding roots of and plotting a function

import numpy as np
import matplotlib.pyplot as plt

#Given function
def func(x):
    return x**4 - 4*x**3 + 8*x + 1

#Derivative of above function
def deriv(x):
    return 4*x**3 - 12*x**2 + 8

#Function to find root
def newton(f, df, x0, eps):
    i = 0
    while abs(f(x0))>eps:
        if df(x0)==0:
            print('No solution found.')
            return None
        x0 = x0 - f(x0)/df(x0)
        i += 1
    return x0, i

#Preparing range
x = np.linspace(-2, 2)
y = func(x)

#Plotting
plt.plot(x, y)
plt.ylim(-5,5)
plt.show()

#Printing root #1 information
root, numIter = newton(func, deriv, -2, 10e-6)
print(f'x = {root}, Iterations = {numIter}')

#Printing root #2 information
root, numIter = newton(func, deriv, 0, 10e-6)
print(f'x = {root}, Iterations = {numIter}')
