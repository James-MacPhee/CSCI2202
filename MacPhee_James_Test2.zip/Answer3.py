#James MacPhee - CSCI2202 Test2
#Question 3 - Calculating female population change over time

import numpy as np

#Starting population and probabilites
P = np.array([[0.3, 0], [0, 0.2]])
x = np.array((8000, 2000)).T

print('Year: [Marry, Single]\n')

#Calculation forward
for i in range(1, 16):
    temp = np.dot(P, x)

    #Updating population
    x[0] += temp[1]
    x[1] += temp[0]
    x[0] -= temp[0]
    x[1] -= temp[1]

    #Reporting results every three years
    if i%3 == 0:
        print(f'{2019+i}: {x}')
