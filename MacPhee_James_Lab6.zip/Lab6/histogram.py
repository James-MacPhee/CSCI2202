#James MacPhee - Lab 6
#Question 2 - Making a histogram of the data produced in 'darts.py'

from darts import counts, intervals
import numpy as np
import matplotlib.pyplot as plt


#Basically followed instructions except wanted to use the actual intervals
labels = []
for i in intervals:
    labels.append(str(i))

fig, bars = plt.subplots()
x = np.arange(len(counts))
bars.bar(x, counts)
bars.set_xticks(x)
bars.set_xticklabels(labels)
plt.show()
