#James MacPhee - CSCI2202 Lab 6
#Question 1 - Using Monte Carlo simulation to estimate pi

#I decided to break the question into two parts with the last section as its -
#own part just so it's easier to see what part is used in the upcoming questions

import random
import numpy as np
from math import pi
from tabulate import tabulate

#Function that calculates pi given number of throws
if __name__ == "__main__":
    print('Part 1')
def throwing(throws):
    num = 0
    for i in range(throws):
        xThrow = random.random()
        yThrow = random.random()
        if xThrow**2 + yThrow**2 <= 1:
            num += 1
    return (4*num)/throws 

#List of # of throws for each run
sims = [10, 100, 1000, 10000]
runs = [throwing(10), throwing(100), throwing(1000), throwing(10000)]

#Utilizing tabulate to make my table
results = [(sims[x], runs[x], (runs[x]-pi)/pi) for x in range(len(sims))]
if __name__ == "__main__":
    print(tabulate(results, headers=["# of Trials", "Estimate", "Relative Error"]))


#Second part
if __name__ == "__main__":
    print('\nPart 2')
k = 6
intervals = np.linspace(3.1, 3.2, k+1)
for i in range(len(intervals)):
    intervals[i] = round(intervals[i], 5)
counts = np.zeros(k)

for i in range(10000): #Running 10000 simulations
    est = throwing(10000) #Doing 10000 throws per simulations
    for j in range(len(intervals)):
        if est<intervals[j]:
            counts[j-1] += 1
            break

#Printing results
if __name__ == "__main__":
    counts = list(counts)
    counts.insert(0, 'Counts:')
    intervals = list(intervals)
    intervals.insert(0, 'Intervals:')
    print(tabulate([counts], headers=intervals))
