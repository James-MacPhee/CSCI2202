#James MacPhee - CSCI2202 Lab 6
#Question 3 - Demonstrating a Monte carlo simulation of calculating e^(-1)

import numpy as np
import random
from math import exp
import matplotlib.pyplot as plt

#Setup
N = int(input("Please enter a number: "))
interval = np.linspace(0,1,N+1)
counts = np.zeros(N)
zeros = 0

#Computation
for i in range(N):
    num = random.random()
    for j in range(len(interval)):
        if num<interval[j]:
            counts[j-1] += 1
            break

for x in counts:
    if x==0:
        zeros += 1

#Printing results
estimate = zeros/N
print(f'\nEstimate: {estimate}\tExact: {exp(-1)}')
print(f'Relative Error: {estimate-exp(-1)}')

#Histogram just like 'histogram.py'
labels = []
for i in interval:
    labels.append(str(i))

fig, bars = plt.subplots()
x = np.arange(len(counts))
bars.bar(x, counts)
bars.set_xticks(x)
bars.set_xticklabels(labels)
plt.show()

