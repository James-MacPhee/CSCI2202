#James MacPhee - CSCI2202 Test 1
#Question 4 - Defines a function that determines leap years -
#and converts an inputted date to day of the year

#Function to determine if argument is a leap year or not
def isLeap(year):
    if (year%4==0 and year%100!=0) or year%400==0:
        return True
    else:
        return False

#Setup
day, month, year = input('Enter a date (DD-MM-YYY): ').split('-')
count = 0
daysPerMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

#Counting of days
for i in range(int(month)):
    count += daysPerMonth[i]
if isLeap(int(year)) and int(month)>2:
    count += 1
count += int(day)

#Printing results
print(f'{day}-{month}-{year} is day {count}')
