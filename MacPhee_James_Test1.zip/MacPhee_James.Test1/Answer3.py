#James MacPhee - CSCI2202 Test 1
#Question 3 - Makes a range of floats

flts = input('Enter floats: start, stop, step: ').split(', ')

#Setup
start = float(flts[0])
stop = float(flts[1])
step = float(flts[2])
rng = []

#Calculating
while start<stop:
    rng.append(start)
    start += step

print(rng)
