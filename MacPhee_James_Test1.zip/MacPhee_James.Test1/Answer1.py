#James MacPhee - CSCI2202 Test 1
#Question 1 - Counts the frequency of DNA bases in a DNA string

dna = input('Enter a DNA string: ')

Acnt = 0
Ccnt = 0
Gcnt = 0
Tcnt = 0

for i in dna:
    if i=='A':
        Acnt += 1
    if i=='C':
        Ccnt += 1
    if i=='G':
        Gcnt += 1
    if i=='T':
        Tcnt += 1

print(f'The frequency of bases is: A:{Acnt}, C:{Ccnt}, G:{Gcnt}, T:{Tcnt}')
