#James MacPhee - CSCI2202 Test 1
#Question 2 - Comoputing a simple sequence

n = int(input('Enter a positive interger: '))

i = 1
seq = [n]
while n!=1:
    if n%2==0:
        n /= 2
    else:
        n *= 3
        n += 1

    i += 1
    seq.append(n)

print(f'The seq. for {n} has length {i}')
print(f'It is: {seq}')
