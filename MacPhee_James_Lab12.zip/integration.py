#James MacPhee - CSCI2202 Lab 12
#Question 1 - Integrates given functions using given methods

import math
import numpy as np

#Integration using trapezoidal rule
def trapezoidal(f, a, b, n):
    length = (b-a)/n
    approximate = f(a) + f(b)
    for i in range(2, n):
        endpoint = length*i + a
        approximate += 2*f(endpoint)
    return approximate*length/2

#Integration using midpoint rule
def midpoint(f, a, b, n):
    length = (b-a)/n
    approximate = 0
    for i in range(n):
        mid = length*i + length/2 + a
        approximate += (length*f(mid))
    return approximate

def simp(f, a, b, n):
    return (2*midpoint(f, a, b, n) + trapezoidal(f, a, b, n))/3

#Mathematical functions to be integrated
def func(x):
    return 1/x

def func2(x):
    return math.e**(0-(x**2))

def func3(x):
    return 3*(x**2)*math.e**(x**3)

#Main function
def main():
    trials = [2, 10, 50, 250]
    exact = math.log(2)
    print('Part a, b, and c')
    print('Error ratios:\t\t\t2/10\t\t10/50\t\t\t50/250\n')

    #Trapezoidal calculations
    errorTrap = np.zeros(4)
    for i in range(len(trials)):
        guess = trapezoidal(func, 1, 2, trials[i])
        errorTrap[i] = exact - guess

    first = errorTrap[0]/errorTrap[1]
    second = errorTrap[1]/errorTrap[2]
    third = errorTrap[2]/errorTrap[3]
    print(f'For Trapezoidal Rule:\t{first}, {second}, {third}')
    
    #Midpoint calculations
    errorMid = np.zeros(4)
    for i in range(len(trials)):
        guess = midpoint(func, 1, 2, trials[i])
        errorMid[i] = exact - guess

    first = errorMid[0]/errorMid[1]
    second = errorMid[1]/errorMid[2]
    third = errorMid[2]/errorMid[3]
    print(f'For Midpoint Rule:\t{first}, {second}, {third}')

    #Simpson's calculations
    errorSimp = np.zeros(4)
    for i in range(len(trials)):
        guess = simp(func, 1, 2, trials[i])
        errorSimp[i] = exact - guess

    first = errorSimp[0]/errorSimp[1]
    second = errorSimp[1]/errorSimp[2]
    third = errorSimp[2]/errorSimp[3]
    print(f'For Simpson\'s Rule:\t{first}, {second}, {third}')

    print('\nPart e (i)')
    print('Using trap. rule: '+str(trapezoidal(func2, 0, 1, 60)))
    print('Using simpson\'s rule: '+str(simp(func2, 0, 1, 60)))

    print('\nPart e (ii)')
    guess = trapezoidal(func3, 0, 1, 400)
    error = abs(math.e-1 - guess)
    print('Exact value: '+str(math.e-1))
    print(f'Using trap. rule: {guess}, error = {error}')
    guess = simp(func3, 0, 1, 200)
    error = abs(math.e-1 - guess)
    print(f'Using simpson\'s rule: {guess}, error = {error}')

if __name__ == '__main__':
    main()
